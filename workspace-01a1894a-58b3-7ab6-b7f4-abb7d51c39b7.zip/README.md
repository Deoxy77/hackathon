# 🛡️ Scam Shield

**One Scam-Detection Brain, Many Channels** — Protecting students and first-time earners from fake jobs, OTP theft, lottery traps, fake bank alerts, and UPI payment scams in local languages.

## Repository Layout (Spec Section 14 — Monorepo Ready)

```text
scam-shield/
├── SCAM_SHIELD_PROJECT_SPEC.md   # Single source of truth & FE/BE API Contract
├── README.md                     # Project root overview
├── backend/                      # Python FastAPI Backend + Scam Detection Engine (Complete)
└── frontend/                     # Partner's Web App UI (merge here, or keep in separate repo)
```

## Quick Links
- **Project Spec & API Contract:** [`SCAM_SHIELD_PROJECT_SPEC.md`](./SCAM_SHIELD_PROJECT_SPEC.md)
- **Backend Setup, Free AI Key Guide & FE Merge Instructions:** [`backend/README.md`](./backend/README.md)
